﻿using System.ComponentModel.DataAnnotations;

namespace coffeeshop.Models
{
    public class Product
    {
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        public string Detail { get; set; }

        [Range(0, double.MaxValue)]
        public decimal Price { get; set; }

        [Url]
        public string ImageUrl { get; set; }

        public bool IsTrendingProduct { get; set; }
    }
}

﻿using Microsoft.AspNetCore.Mvc;
using coffeeshop.Models;

namespace YourProject.Controllers
{
    public class ProductController : Controller
    {
        // Giả lập danh sách sản phẩm
        public IActionResult Index()
        {
            var products = new List<Product>
            {
                new Product { Id = 1, Name = "Cà Phê Sữa", Price = 30 },
                new Product { Id = 2, Name = "Cà Phê Đen", Price = 25 }
            };

            return View(products);
        }
    }
}
